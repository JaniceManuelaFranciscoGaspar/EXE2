package com.example.exe2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText nome,nome1;
  Button btn;
  TextView texto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nome=findViewById(R.id.txt1);
        nome1=findViewById(R.id.txt2);
        btn=findViewById(R.id.btn);
        texto=findViewById(R.id.texto);
    }
    public void onclick(View v){

        String nom1 =nome.getText().toString();
        String nom2 =nome1.getText().toString();
        if (nom1.equals("") || nom2.equals("" ))
        {
            texto.setText(" Nome não inserido");
        }
        else{
        texto.setText( " Olá " + nom1 + " " + nom2);
    }

        }
    }